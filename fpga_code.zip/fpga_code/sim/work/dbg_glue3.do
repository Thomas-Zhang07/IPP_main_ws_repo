run 566.5 us
examine -radix binary /tb_glue/channel_array/insts(0)/PhaseLine_inst/pulse
examine -radix unsigned /tb_glue/channel_array/insts(0)/PhaseLine_inst/s_counter
examine -radix unsigned /tb_glue/channel_array/insts(0)/PhaseLine_inst/s_phaseCurrent
examine -radix unsigned /tb_glue/channel_array/insts(1)/PhaseLine_inst/s_phaseCurrent
examine -radix unsigned /tb_glue/channel_array/insts(3)/PhaseLine_inst/s_phaseCurrent
examine -radix unsigned /tb_glue/channel_array/insts(5)/PhaseLine_inst/s_phaseCurrent
examine -radix binary /tb_glue/channel_array/music_out
examine -radix unsigned /tb_glue/count
quit -f
