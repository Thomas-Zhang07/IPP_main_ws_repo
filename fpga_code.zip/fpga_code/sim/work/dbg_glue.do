run 600 us
examine -radix binary /tb_glue/dist/s_swap_out
examine -radix binary /tb_glue/dist/s_set_out
examine -radix unsigned /tb_glue/dist/s_ByteCounter
examine -radix unsigned /tb_glue/dist/s_address
examine -radix unsigned /tb_glue/dist/s_data_out
examine -radix unsigned /tb_glue/channel_array/insts(0)/PhaseLine_inst/s_phaseCurrent
examine -radix unsigned /tb_glue/channel_array/insts(1)/PhaseLine_inst/s_phaseCurrent
examine -radix unsigned /tb_glue/channel_array/insts(2)/PhaseLine_inst/s_phaseCurrent
examine -radix unsigned /tb_glue/channel_array/insts(7)/PhaseLine_inst/s_phaseCurrent
examine -radix unsigned /tb_glue/channel_array/insts(8)/PhaseLine_inst/s_phaseCurrent
quit -f
