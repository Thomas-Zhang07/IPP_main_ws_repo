run 520 us
examine -radix binary /tb_glue/dist/s_swap_out
examine -radix unsigned /tb_glue/dist/s_ByteCounter
run 20 us
examine -radix binary /tb_glue/dist/s_swap_out
examine -radix unsigned /tb_glue/dist/s_ByteCounter
run 20 us
examine -radix binary /tb_glue/dist/s_swap_out
examine -radix unsigned /tb_glue/dist/s_ByteCounter
run 20 us
examine -radix binary /tb_glue/dist/s_swap_out
examine -radix unsigned /tb_glue/dist/s_ByteCounter
quit -f
