run 570 us
examine -radix binary /tb_glue/channel_array/music_out
run 10 us
examine -radix binary /tb_glue/channel_array/music_out
run 10 us
examine -radix binary /tb_glue/channel_array/music_out
run 200 us
examine -radix binary /tb_glue/channel_array/music_out
run 10 us
examine -radix binary /tb_glue/channel_array/music_out
quit -f
