run 520 us
examine -radix binary /tb_glue/swap_e
examine -radix binary /tb_glue/set_e
examine -radix unsigned /tb_glue/channel_array/insts(0)/PhaseLine_inst/s_phasePrev
examine -radix unsigned /tb_glue/channel_array/insts(0)/PhaseLine_inst/s_phaseCurrent
examine -radix binary /tb_glue/channel_array/insts(0)/PhaseLine_inst/s_prevSwap
run 46.5 us
examine -radix binary /tb_glue/swap_e
examine -radix binary /tb_glue/set_e
examine -radix unsigned /tb_glue/channel_array/insts(0)/PhaseLine_inst/s_phasePrev
examine -radix unsigned /tb_glue/channel_array/insts(0)/PhaseLine_inst/s_phaseCurrent
examine -radix binary /tb_glue/channel_array/insts(0)/PhaseLine_inst/s_prevSwap
quit -f
