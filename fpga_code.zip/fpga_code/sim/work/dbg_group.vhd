library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;

-- Scratch diagnostic: turn a whole group off in one swap and log DATA(0).
entity dbg_group is
end entity;

architecture sim of dbg_group is
    constant CLK8_PERIOD : time := 195313 ps;
    signal clk8     : std_logic := '0';
    signal clk      : std_logic;
    signal count    : std_logic_vector(7 downto 0) := (others => '0');
    signal swap, set : std_logic := '0';
    signal phase    : std_logic_vector(7 downto 0) := (others => '0');
    signal address  : std_logic_vector(7 downto 0) := (others => '0');
    signal mode     : std_logic_vector(1 downto 0) := "00";
    signal music_out : std_logic_vector(31 downto 0);
    signal finished : boolean := false;
    signal log_on   : std_logic := '0';
    signal prev     : std_logic := '1';
begin
    clk8 <= not clk8 after CLK8_PERIOD / 2 when not finished else '0';

    process (clk8) begin
        if rising_edge(clk8) then
            count <= std_logic_vector(unsigned(count) + 1);
            if log_on = '1' and music_out(0) /= prev then
                report "OUT0 " & time'image(now) & " = " & std_logic'image(music_out(0)) severity note;
            end if;
            prev <= music_out(0);
        end if;
    end process;

    clk <= count(2);

    dut : entity work.AllChannels
        generic map (NBLOCKS => 256)
        port map (clk8 => clk8, clk => clk, counter => count, swap => swap,
                  phase => phase, set => set, address => address,
                  mode => mode, music_out => music_out);

    stim : process
    begin
        wait for 50 us;
        log_on <= '1';
        wait for 100 us;

        set <= '1';
        address <= x"00"; phase <= x"10"; wait until rising_edge(clk); wait for 1 ns;
        address <= x"01"; phase <= x"10"; wait until rising_edge(clk); wait for 1 ns;
        address <= x"02"; phase <= x"10"; wait until rising_edge(clk); wait for 1 ns;
        address <= x"03"; phase <= x"10"; wait until rising_edge(clk); wait for 1 ns;
        address <= x"04"; phase <= x"10"; wait until rising_edge(clk); wait for 1 ns;
        address <= x"05"; phase <= x"10"; wait until rising_edge(clk); wait for 1 ns;
        address <= x"06"; phase <= x"10"; wait until rising_edge(clk); wait for 1 ns;
        address <= x"07"; phase <= x"10"; wait until rising_edge(clk); wait for 1 ns;
        set <= '0';
        wait until rising_edge(clk); wait until rising_edge(clk);
        swap <= '1'; wait until rising_edge(clk); wait until rising_edge(clk); swap <= '0';
        wait until rising_edge(clk); wait until rising_edge(clk);
        report "swap done" severity note;
        wait for 200 us;

        finished <= true;
        report "DONE" severity note;
        wait;
    end process;
end architecture;
