run 2.0 ms
examine -radix unsigned {/tb_top/dut/\inst6|s_ByteCounter\}
examine -radix binary {/tb_top/dut/\inst6|s_boardEnable\}
examine -radix binary {/tb_top/dut/\inst6|s_data_out\}
examine -radix binary {/tb_top/dut/\inst6|s_address\}
quit -f
