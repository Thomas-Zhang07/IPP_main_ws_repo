run 2.0 ms
examine -radix unsigned "/tb_top/dut/\\inst6|s_ByteCounter\\"
examine -radix binary "/tb_top/dut/\\inst6|s_boardEnable\\"
examine -radix binary "/tb_top/dut/\\inst6|s_data_out\\"
examine -radix binary "/tb_top/dut/\\inst6|s_address\\"
run 1.3 ms
examine -radix unsigned "/tb_top/dut/\\inst8|insts:0:PhaseLine_inst|s_phaseCurrent\\"
examine -radix unsigned "/tb_top/dut/\\inst8|insts:1:PhaseLine_inst|s_phaseCurrent\\"
examine -radix unsigned "/tb_top/dut/\\inst8|insts:8:PhaseLine_inst|s_phaseCurrent\\"
quit -f
