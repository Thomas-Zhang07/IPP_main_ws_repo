run 3.480 ms
examine -radix binary /tb_top/dut/ww_DATA
run 12 us
examine -radix binary /tb_top/dut/ww_DATA
run 37 us
examine -radix binary /tb_top/dut/ww_DATA
quit -f
