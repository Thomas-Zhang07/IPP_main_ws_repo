run 3.50 ms
examine "/tb_top/dut/\\inst8|insts:0:PhaseLine_inst|pulse\\"
examine "/tb_top/dut/\\inst8|insts:1:PhaseLine_inst|pulse\\"
examine "/tb_top/dut/\\inst8|insts:8:PhaseLine_inst|pulse\\"
run 10 us
examine "/tb_top/dut/\\inst8|insts:0:PhaseLine_inst|pulse\\"
examine "/tb_top/dut/\\inst8|insts:1:PhaseLine_inst|pulse\\"
examine "/tb_top/dut/\\inst8|insts:8:PhaseLine_inst|pulse\\"
run 10 us
examine "/tb_top/dut/\\inst8|insts:0:PhaseLine_inst|pulse\\"
examine "/tb_top/dut/\\inst8|insts:1:PhaseLine_inst|pulse\\"
examine "/tb_top/dut/\\inst8|insts:8:PhaseLine_inst|pulse\\"
quit -f
