library IEEE;
use IEEE.std_logic_1164.all;

package phase_correction_pkg is
  type correction_array is array (0 to 255) of integer range 0 to 255;
  constant PHASE_CORRECTION : correction_array := (
    0, 0, 0, 0, 0, 0, 8, 0, 8, 8, 0, 0, 8, 8, 8, 0,
    8, 0, 8, 0, 8, 8, 8, 8, 0, 8, 0, 8, 0, 8, 0, 8,
    0, 8, 0, 0, 8, 8, 8, 8, 0, 8, 8, 0, 0, 0, 8, 8,
    0, 0, 8, 8, 8, 0, 8, 8, 8, 8, 0, 0, 0, 0, 8, 8,
    8, 0, 0, 8, 8, 8, 8, 8, 0, 0, 0, 8, 8, 0, 0, 8,
    0, 0, 8, 8, 8, 8, 0, 0, 8, 0, 0, 0, 8, 0, 0, 0,
    8, 0, 8, 8, 0, 0, 0, 0, 0, 8, 0, 8, 8, 0, 8, 0,
    0, 0, 0, 0, 0, 0, 8, 0, 8, 8, 0, 8, 8, 0, 0, 8,
    0, 0, 8, 8, 8, 8, 0, 0, 8, 0, 0, 8, 8, 0, 0, 8,
    8, 0, 0, 0, 0, 0, 0, 0, 8, 0, 8, 0, 0, 0, 0, 0,
    8, 0, 0, 0, 8, 8, 0, 8, 8, 0, 0, 0, 8, 8, 0, 0,
    0, 0, 0, 8, 0, 0, 0, 8, 0, 0, 8, 0, 8, 0, 0, 0,
    0, 8, 0, 8, 8, 0, 8, 8, 8, 0, 8, 8, 8, 0, 8, 8,
    8, 8, 0, 0, 8, 0, 0, 0, 8, 8, 0, 8, 0, 0, 8, 8,
    8, 8, 8, 0, 0, 8, 0, 8, 0, 0, 0, 0, 8, 0, 0, 8,
    0, 8, 0, 8, 0, 8, 0, 0, 0, 8, 0, 8, 8, 8, 8, 8
  );

  -- Value Distribute stores for one payload byte.
  function corrected(bin_value : integer; index : integer) return integer;
end package;

package body phase_correction_pkg is
  function corrected(bin_value : integer; index : integer) return integer is
  begin
    if bin_value = 16 then
      return 16;
    end if;
    return (bin_value + PHASE_CORRECTION(index)) mod 16;
  end function;
end package body;
